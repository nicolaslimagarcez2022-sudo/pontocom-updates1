const { app, BrowserWindow, ipcMain, dialog, Notification } = require("electron");
const path = require("path");
const fs = require("fs");
const http = require("http");
const https = require("https");
const os = require("os");

// ── "Banco de dados" local: um arquivo JSON dentro da pasta de dados do
// usuário do Windows (algo como C:\Users\<usuario>\AppData\Roaming\Pontocom Transporte).
// Quando o modo de rede é "servidor", este é o arquivo que TODOS os
// computadores acabam usando (os outros se conectam nele pela rede).
function dataFile() {
  return path.join(app.getPath("userData"), "pontocom-data.json");
}

// ── Pasta de atualizações: fica dentro dos dados do computador SERVIDOR.
// Quando você fizer uma alteração no programa (ex.: adicionar um bairro),
// gera o instalador novo e coloca ele nessa pasta, no PC servidor. Os
// computadores clientes vão enxergar sozinhos que tem versão nova.
function updatesFolder() {
  const dir = path.join(app.getPath("userData"), "updates");
  try { fs.mkdirSync(dir, { recursive: true }); } catch {}
  return dir;
}
// Acha o instalador mais recente (.exe) dentro da pasta de atualizações,
// pelo mais recente a ser modificado — assim não precisa ficar com nome fixo.
function findLatestInstaller() {
  const dir = updatesFolder();
  let files;
  try { files = fs.readdirSync(dir).filter(f => f.toLowerCase().endsWith(".exe")); } catch { files = []; }
  if (!files.length) return null;
  const withStats = files.map(f => ({ f, t: fs.statSync(path.join(dir, f)).mtimeMs }));
  withStats.sort((a, b) => b.t - a.t);
  return path.join(dir, withStats[0].f);
}
// Número da versão que o servidor está anunciando para os clientes. Fica
// num arquivinho separado (version.txt) pra você poder editar à mão se
// quiser, sem precisar mexer no instalador. Se não existir, usa a versão
// do próprio programa instalado no servidor (package.json).
function serverAnnouncedVersion() {
  try {
    const v = fs.readFileSync(path.join(updatesFolder(), "version.txt"), "utf-8").trim();
    if (v) return v;
  } catch {}
  return app.getVersion();
}

// ── Atualização pela INTERNET (funciona em redes diferentes) ──────────────
// Diferente da atualização pela rede local (que depende do PC servidor
// estar ligado e na mesma rede), esta usa um link público na internet —
// normalmente um arquivo JSON hospedado no GitHub (Releases) — que qualquer
// computador, em qualquer rede, consegue checar e baixar.
//
// Esse link já vem PRONTO DE FÁBRICA aqui embaixo — nenhum computador
// precisa colar nada, só clicar em "Verificar atualizações". Se um dia
// você trocar de repositório no GitHub, troque só esse valor aqui e gere
// uma nova versão.
const DEFAULT_UPDATE_MANIFEST_URL =
  "https://raw.githubusercontent.com/nicolaslimagarcez2022-sudo/pontocom-updates/refs/heads/main/latest.json";

function updateConfigFile() {
  return path.join(app.getPath("userData"), "pontocom-update-config.json");
}
function readUpdateConfig() {
  try {
    const salvo = JSON.parse(fs.readFileSync(updateConfigFile(), "utf-8"));
    if (salvo && salvo.manifestUrl) return salvo;
  } catch {}
  return { manifestUrl: DEFAULT_UPDATE_MANIFEST_URL, ehPadrao: true };
}
function writeUpdateConfig(cfg) {
  fs.writeFileSync(updateConfigFile(), JSON.stringify(cfg), "utf-8");
}

// Faz um GET seguindo redirecionamentos (o link de download do GitHub
// Releases redireciona várias vezes antes de chegar no arquivo de verdade).
function httpGetSeguindoRedirect(urlStr, maxRedirs = 6) {
  return new Promise((resolve, reject) => {
    const tentar = (u, restantes) => {
      const mod = u.startsWith("https:") ? https : http;
      const req = mod.get(u, { headers: { "User-Agent": "PontocomTransporte" } }, (res) => {
        if ([301,302,303,307,308].includes(res.statusCode) && res.headers.location && restantes > 0) {
          res.resume();
          tentar(new URL(res.headers.location, u).toString(), restantes - 1);
          return;
        }
        resolve(res);
      });
      req.setTimeout(8000, () => req.destroy(new Error("timeout")));
      req.on("error", reject);
    };
    tentar(urlStr, maxRedirs);
  });
}
function fetchJsonInternet(urlStr) {
  return new Promise(async (resolve, reject) => {
    try {
      const res = await httpGetSeguindoRedirect(urlStr);
      if (res.statusCode !== 200) { reject(new Error("HTTP " + res.statusCode)); return; }
      let data = "";
      res.on("data", c => data += c);
      res.on("end", () => { try { resolve(JSON.parse(data)); } catch (e) { reject(e); } });
      res.on("error", reject);
    } catch (e) { reject(e); }
  });
}
function baixarArquivoInternet(urlStr, destino, onProgress) {
  return new Promise(async (resolve, reject) => {
    try {
      const res = await httpGetSeguindoRedirect(urlStr);
      if (res.statusCode !== 200) { reject(new Error("HTTP " + res.statusCode)); return; }
      const total = parseInt(res.headers["content-length"] || "0", 10);
      let baixado = 0;
      const out = fs.createWriteStream(destino);
      res.on("data", (chunk) => {
        baixado += chunk.length;
        if (onProgress) onProgress(total ? Math.round((baixado / total) * 100) : null);
      });
      res.pipe(out);
      out.on("finish", () => out.close(() => resolve()));
      out.on("error", reject);
      res.on("error", reject);
    } catch (e) { reject(e); }
  });
}

function readStore() {
  try {
    return JSON.parse(fs.readFileSync(dataFile(), "utf-8"));
  } catch {
    return {};
  }
}

function writeStore(store) {
  fs.writeFileSync(dataFile(), JSON.stringify(store), "utf-8");
}

// ── Configuração de rede (não é dado compartilhado — é local de cada PC:
// diz se este computador é "servidor", "cliente" de outro, ou "standalone"). ──
function netConfigFile() {
  return path.join(app.getPath("userData"), "pontocom-network.json");
}
function readNetConfig() {
  try {
    const cfg = JSON.parse(fs.readFileSync(netConfigFile(), "utf-8"));
    return { mode: "standalone", serverIp: "", port: 4750, ...cfg };
  } catch {
    return { mode: "standalone", serverIp: "", port: 4750 };
  }
}
function writeNetConfig(cfg) {
  fs.writeFileSync(netConfigFile(), JSON.stringify(cfg), "utf-8");
}

function localIps() {
  const nets = os.networkInterfaces();
  const ips = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === "IPv4" && !net.internal) ips.push(net.address);
    }
  }
  return ips;
}

// ── Modo SERVIDOR: sobe um servidor HTTP simples na rede local ────────────
// Outros PCs (modo "cliente") leem/gravam dados aqui em vez do arquivo
// local deles, e recebem avisos em tempo real (Server-Sent Events) sempre
// que algo muda, pra tela deles atualizar sozinha.
let sseClients = [];
function broadcastChange(key) {
  const msg = `data: ${JSON.stringify({ key })}\n\n`;
  sseClients = sseClients.filter(res => {
    try { res.write(msg); return true; } catch { return false; }
  });
  // O servidor avisava os OUTROS computadores (clientes) via SSE, mas nunca
  // avisava a própria tela dele quando um cliente mandava um dado novo — por
  // isso quem estava no PC servidor não via a entrega aparecer sem
  // deslogar/logar de novo. Agora a própria janela do servidor também recebe
  // o aviso, igual um cliente qualquer.
  BrowserWindow.getAllWindows().forEach(w => {
    try { w.webContents.send("storage:changed", key); } catch {}
  });
}

let httpServer = null;
function startServer(port) {
  if (httpServer) return httpServer;
  httpServer = http.createServer((req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    if (req.method === "OPTIONS") { res.writeHead(204); res.end(); return; }

    if (req.url === "/ping") { res.writeHead(200, { "Content-Type": "application/json" }); res.end(JSON.stringify({ ok:true })); return; }

    if (req.url === "/update/version") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ version: serverAnnouncedVersion(), temInstalador: !!findLatestInstaller() }));
      return;
    }

    if (req.url === "/update/installer" && req.method === "GET") {
      const file = findLatestInstaller();
      if (!file) { res.writeHead(404); res.end("sem instalador"); return; }
      res.writeHead(200, {
        "Content-Type": "application/octet-stream",
        "Content-Disposition": `attachment; filename="${path.basename(file)}"`,
        "Content-Length": fs.statSync(file).size,
      });
      fs.createReadStream(file).pipe(res);
      return;
    }

    if (req.url === "/events") {
      res.writeHead(200, {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
      });
      res.write("\n");
      sseClients.push(res);
      req.on("close", () => { sseClients = sseClients.filter(c => c !== res); });
      return;
    }

    if (req.url.startsWith("/storage/") && req.method === "GET") {
      const key = decodeURIComponent(req.url.slice("/storage/".length));
      const store = readStore();
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify(key in store ? { key, value: store[key] } : null));
      return;
    }

    if (req.url.startsWith("/storage/") && req.method === "POST") {
      const key = decodeURIComponent(req.url.slice("/storage/".length));
      let body = "";
      req.on("data", c => body += c);
      req.on("end", () => {
        try {
          const { value } = JSON.parse(body);
          const store = readStore();
          store[key] = value;
          writeStore(store);
          broadcastChange(key);
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ key, value }));
        } catch (e) {
          res.writeHead(400); res.end("bad request");
        }
      });
      return;
    }

    res.writeHead(404); res.end("not found");
  });
  httpServer.listen(port, "0.0.0.0");
  return httpServer;
}
function stopServer() {
  if (httpServer) { try { httpServer.close(); } catch {} httpServer = null; }
  sseClients.forEach(c => { try { c.end(); } catch {} });
  sseClients = [];
}

// ── Modo CLIENTE: fala com o servidor de outro PC pela rede ───────────────
function remoteUrl(cfg, pathStr) {
  return `http://${cfg.serverIp}:${cfg.port}${pathStr}`;
}

let sseRequest = null;
function connectToServerEvents(cfg, getWindows) {
  if (sseRequest) { try { sseRequest.destroy(); } catch {} sseRequest = null; }
  const tryConnect = () => {
    const req = http.get(remoteUrl(cfg, "/events"), (res) => {
      let buffer = "";
      res.on("data", (chunk) => {
        buffer += chunk.toString();
        let idx;
        while ((idx = buffer.indexOf("\n\n")) !== -1) {
          const raw = buffer.slice(0, idx);
          buffer = buffer.slice(idx + 2);
          const line = raw.split("\n").find(l => l.startsWith("data: "));
          if (line) {
            try {
              const parsed = JSON.parse(line.slice(6));
              getWindows().forEach(w => w.webContents.send("storage:changed", parsed.key));
            } catch {}
          }
        }
      });
      res.on("end", () => { setTimeout(() => connectToServerEvents(cfg, getWindows), 2000); });
      res.on("error", () => { setTimeout(() => connectToServerEvents(cfg, getWindows), 2000); });
    });
    req.on("error", () => { setTimeout(() => connectToServerEvents(cfg, getWindows), 2000); });
    sseRequest = req;
  };
  tryConnect();
}

function httpJson(urlStr, options, bodyObj) {
  return new Promise((resolve, reject) => {
    const req = http.request(urlStr, options, (res) => {
      let data = "";
      res.on("data", c => data += c);
      res.on("end", () => {
        try { resolve(data ? JSON.parse(data) : null); } catch (e) { reject(e); }
      });
    });
    req.on("error", reject);
    req.setTimeout(3000, () => req.destroy(new Error("timeout")));
    if (bodyObj !== undefined) req.write(JSON.stringify(bodyObj));
    req.end();
  });
}

// ── IPC: storage — decide sozinho/servidor/cliente conforme a configuração ─
// Importante: se o modo é "cliente" e a conexão falha, NÃO tratamos como
// "sem dados" (isso fazia parecer que usuário/senha estavam errados quando
// na verdade era falta de conexão com o servidor). Em vez disso, devolvemos
// um erro específico pro app conseguir mostrar a mensagem certa.
ipcMain.handle("storage:get", async (_event, key) => {
  const cfg = readNetConfig();
  if (cfg.mode === "cliente" && cfg.serverIp) {
    try {
      return await httpJson(remoteUrl(cfg, `/storage/${encodeURIComponent(key)}`), { method: "GET" });
    } catch (e) {
      throw new Error("SEM_CONEXAO_SERVIDOR");
    }
  }
  const store = readStore();
  return key in store ? { key, value: store[key] } : null;
});

ipcMain.handle("storage:set", async (_event, key, value) => {
  const cfg = readNetConfig();
  if (cfg.mode === "cliente" && cfg.serverIp) {
    try {
      return await httpJson(
        remoteUrl(cfg, `/storage/${encodeURIComponent(key)}`),
        { method: "POST", headers: { "Content-Type": "application/json" } },
        { value }
      );
    } catch (e) {
      throw new Error("SEM_CONEXAO_SERVIDOR");
    }
  }
  const store = readStore();
  store[key] = value;
  writeStore(store);
  if (cfg.mode === "servidor") broadcastChange(key);
  return { key, value };
});

// ── IPC: configuração de rede ───────────────────────────────────────────────
ipcMain.handle("network:getConfig", async () => {
  return { ...readNetConfig(), localIps: localIps() };
});

ipcMain.handle("network:setConfig", async (_event, cfg) => {
  writeNetConfig({ mode: cfg.mode, serverIp: cfg.serverIp || "", port: cfg.port || 4750 });
  app.relaunch();
  app.exit(0);
});

ipcMain.handle("network:testConnection", async (_event, ip, port) => {
  try {
    const r = await httpJson(`http://${ip}:${port}/ping`, { method: "GET" });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: String(e.message || e) };
  }
});

// Checa se, com a configuração ATUAL, dá pra falar com o servidor agora.
// Usado pra mostrar um aviso claro (em vez de "usuário/senha incorretos")
// quando o problema é a rede, não o login.
ipcMain.handle("network:status", async () => {
  const cfg = readNetConfig();
  if (cfg.mode !== "cliente") return { mode: cfg.mode, connected: true };
  if (!cfg.serverIp) return { mode: cfg.mode, connected: false };
  try {
    await httpJson(`http://${cfg.serverIp}:${cfg.port}/ping`, { method: "GET" });
    return { mode: cfg.mode, connected: true, serverIp: cfg.serverIp, port: cfg.port };
  } catch (e) {
    return { mode: cfg.mode, connected: false, serverIp: cfg.serverIp, port: cfg.port };
  }
});

// ── IPC: atualização automática ─────────────────────────────────────────────
// Compara "1.2.10" com "1.2.9" (etc.) por partes numéricas, não como texto.
function versaoMaisNova(a, b) {
  const pa = String(a).split(".").map(n => parseInt(n, 10) || 0);
  const pb = String(b).split(".").map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x !== y) return x > y;
  }
  return false;
}

// ── IPC: configuração do link de atualização pela internet ────────────────
ipcMain.handle("updateconfig:get", async () => {
  return readUpdateConfig();
});
ipcMain.handle("updateconfig:set", async (_event, cfg) => {
  writeUpdateConfig({ manifestUrl: (cfg && cfg.manifestUrl || "").trim() });
  return { ok: true };
});

// Verifica se tem atualização disponível. Tenta primeiro pela INTERNET
// (funciona em qualquer rede), e se não tiver link configurado, cai pra
// checagem pela rede local (precisa estar em modo "cliente").
ipcMain.handle("update:check", async () => {
  const atual = app.getVersion();
  const updCfg = readUpdateConfig();

  if (updCfg.manifestUrl) {
    try {
      const manifest = await fetchJsonInternet(updCfg.manifestUrl);
      const nova = manifest && manifest.version;
      const temAtualizacao = !!nova && !!manifest.url && versaoMaisNova(nova, atual);
      return { ok: true, atual, servidorVersao: nova, temAtualizacao, fonte: "internet", downloadUrl: manifest && manifest.url };
    } catch (e) {
      return { ok: false, atual, error: "Não foi possível checar o link de atualização configurado. Confira sua conexão com a internet e o link em Rede." };
    }
  }

  const cfg = readNetConfig();
  if (cfg.mode !== "cliente" || !cfg.serverIp) {
    return { ok: true, atual, temAtualizacao: false, motivo: "Configure um link de atualização (internet) ou conecte este computador a um servidor na rede local." };
  }
  try {
    const info = await httpJson(`http://${cfg.serverIp}:${cfg.port}/update/version`, { method: "GET" });
    const nova = info && info.version;
    const temAtualizacao = !!nova && versaoMaisNova(nova, atual) && !!info.temInstalador;
    return { ok: true, atual, servidorVersao: nova, temInstalador: !!(info && info.temInstalador), temAtualizacao, fonte: "rede-local" };
  } catch (e) {
    return { ok: false, atual, error: "SEM_CONEXAO_SERVIDOR" };
  }
});

// Baixa o instalador novo — pela internet (se veio de lá no check) ou do
// servidor da rede local.
ipcMain.handle("update:download", async (event, downloadUrl) => {
  const destino = path.join(app.getPath("temp"), "PontocomTransporte-Atualizacao.exe");
  if (downloadUrl) {
    await baixarArquivoInternet(downloadUrl, destino, (pct) => {
      try { event.sender.send("update:progress", pct); } catch {}
    });
    return { ok: true, caminho: destino };
  }
  const cfg = readNetConfig();
  if (cfg.mode !== "cliente" || !cfg.serverIp) throw new Error("SEM_ORIGEM_DE_ATUALIZACAO");
  await new Promise((resolve, reject) => {
    const req = http.get(`http://${cfg.serverIp}:${cfg.port}/update/installer`, (res) => {
      if (res.statusCode !== 200) { reject(new Error("Instalador não encontrado no servidor")); return; }
      const total = parseInt(res.headers["content-length"] || "0", 10);
      let baixado = 0;
      const out = fs.createWriteStream(destino);
      res.on("data", (chunk) => {
        baixado += chunk.length;
        try { event.sender.send("update:progress", total ? Math.round((baixado / total) * 100) : null); } catch {}
      });
      res.pipe(out);
      out.on("finish", () => out.close(() => resolve()));
      out.on("error", reject);
    });
    req.on("error", reject);
  });
  return { ok: true, caminho: destino };
});

// Abre o instalador baixado (o Windows mostra a telinha normal de instalação)
// e fecha o programa atual pra não travar a atualização dos arquivos.
ipcMain.handle("update:install", async (_event, caminhoInstalador) => {
  const { shell } = require("electron");
  await shell.openPath(caminhoInstalador);
  setTimeout(() => app.exit(0), 800);
  return { ok: true };
});

// Lê o arquivo LOCAL direto (ignorando o modo de rede) — usado só pra
// recuperar dados/usuários que ficaram "presos" neste PC antes de ele virar
// cliente de outro servidor, e poder enviar pro servidor depois.
ipcMain.handle("network:localSnapshot", async () => {
  return readStore();
});

// Mescla os dados deste PC (local) com os do Servidor, PARA UM USUÁRIO
// ESPECÍFICO — sem apagar nada de nenhum dos dois lados. Junta as listas
// de clientes/entregas/caixa/arquivadas comparando pelo "id" de cada item
// (cada cadastro tem um id único, então dá pra juntar sem duplicar).
function mergeById(a, b) {
  const arrA = Array.isArray(a) ? a : [];
  const arrB = Array.isArray(b) ? b : [];
  const map = new Map();
  [...arrA, ...arrB].forEach(item => {
    if (item && item.id != null) map.set(item.id, item);
  });
  return Array.from(map.values());
}

ipcMain.handle("network:mergeLocalIntoServer", async (_event, username) => {
  const cfg = readNetConfig();
  if (cfg.mode !== "cliente" || !cfg.serverIp) return { ok: false, error: "Este PC não está em modo Cliente." };
  if (!username) return { ok: false, error: "Usuário não informado." };

  const uKey = `gasctrl:user:${username}`;
  const aKey = `gasctrl:archive:${username}`;
  const local = readStore();
  const localUser = local[uKey] || { clients: [], deliveries: [], caixas: [] };
  const localArchive = local[aKey] || [];

  try {
    const remoteUserResp = await httpJson(remoteUrl(cfg, `/storage/${encodeURIComponent(uKey)}`), { method: "GET" });
    const remoteArchiveResp = await httpJson(remoteUrl(cfg, `/storage/${encodeURIComponent(aKey)}`), { method: "GET" });
    const remoteUser = (remoteUserResp && remoteUserResp.value) || { clients: [], deliveries: [], caixas: [] };
    const remoteArchive = (remoteArchiveResp && remoteArchiveResp.value) || [];

    const mergedUser = {
      clients: mergeById(remoteUser.clients, localUser.clients),
      deliveries: mergeById(remoteUser.deliveries, localUser.deliveries),
      caixas: mergeById(remoteUser.caixas, localUser.caixas),
    };
    const mergedArchive = mergeById(remoteArchive, localArchive);

    await httpJson(
      remoteUrl(cfg, `/storage/${encodeURIComponent(uKey)}`),
      { method: "POST", headers: { "Content-Type": "application/json" } },
      { value: mergedUser }
    );
    await httpJson(
      remoteUrl(cfg, `/storage/${encodeURIComponent(aKey)}`),
      { method: "POST", headers: { "Content-Type": "application/json" } },
      { value: mergedArchive }
    );

    return {
      ok: true,
      entregas: mergedUser.deliveries.length,
      clientes: mergedUser.clients.length,
      caixas: mergedUser.caixas.length,
    };
  } catch (e) {
    return { ok: false, error: String(e.message || e) };
  }
});

// ── Backup em pasta escolhida pelo usuário (janela nativa do Windows) ──────
ipcMain.handle("backup:chooseFolder", async (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  const result = await dialog.showOpenDialog(win, {
    title: "Escolher pasta de backup",
    properties: ["openDirectory", "createDirectory"],
  });
  if (result.canceled || result.filePaths.length === 0) return null;
  return result.filePaths[0];
});

ipcMain.handle("backup:saveFile", async (_event, folderPath, filename, content) => {
  try {
    fs.mkdirSync(folderPath, { recursive: true });
    const filePath = path.join(folderPath, filename);
    fs.writeFileSync(filePath, content, "utf-8");
    return { ok: true, filePath };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
});

// ── Aviso diário de backup (18:50) ─────────────────────────────────────────
// Todo dia, às 18:50 (horário do computador), mostra uma notificação do
// Windows lembrando de fazer o backup — e também avisa a tela do programa,
// que mostra uma faixa de aviso por dentro (caso a notificação do Windows
// passe despercebida ou esteja desligada nas configurações do sistema).
// Só avisa 1 vez por dia, mesmo que o programa fique aberto o dia inteiro.
let ultimoDiaAvisoBackup = null;
function dataDeHojeStr(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function dispararAvisoDeBackup() {
  try {
    if (Notification.isSupported()) {
      const iconPath = path.join(__dirname, "build", "icon.ico");
      const notif = new Notification({
        title: "Pontocom Transporte",
        body: "⏰ São 18:50 — não esqueça de fazer o backup das entregas de hoje!",
        icon: fs.existsSync(iconPath) ? iconPath : undefined,
      });
      notif.on("click", () => {
        const win = BrowserWindow.getAllWindows()[0];
        if (win) { win.show(); win.focus(); }
      });
      notif.show();
    }
  } catch {}
  BrowserWindow.getAllWindows().forEach(w => {
    try { w.webContents.send("backup:lembrete"); } catch {}
  });
}
function checarAvisoDeBackup() {
  const agora = new Date();
  const hojeStr = dataDeHojeStr(agora);
  if (agora.getHours() === 18 && agora.getMinutes() === 50 && ultimoDiaAvisoBackup !== hojeStr) {
    ultimoDiaAvisoBackup = hojeStr;
    dispararAvisoDeBackup();
  }
}

function createWindow() {
  const iconPath = path.join(__dirname, "build", "icon.ico");
  const win = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 380,
    minHeight: 600,
    ...(fs.existsSync(iconPath) ? { icon: iconPath } : {}),
    webPreferences: {
      // Sem preload.js: liberamos nodeIntegration para a tela poder falar
      // direto com o Electron (ipcRenderer). Como este app não abre sites
      // externos nem conteúdo de terceiros, isso é seguro aqui.
      nodeIntegration: true,
      contextIsolation: false,
    },
  });
  win.setMenuBarVisibility(false);
  win.loadFile("index.html");
  return win;
}

app.whenReady().then(() => {
  const win = createWindow();
  const cfg = readNetConfig();

  if (cfg.mode === "servidor") {
    startServer(cfg.port || 4750);
  } else if (cfg.mode === "cliente" && cfg.serverIp) {
    connectToServerEvents(cfg, () => BrowserWindow.getAllWindows());
  }

  // Confere a cada 20 segundos se já bateu 18:50 pra disparar o aviso de
  // backup (e confere uma vez assim que o programa abre, caso ele já seja
  // aberto depois das 18:50).
  setInterval(checarAvisoDeBackup, 20000);
  checarAvisoDeBackup();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  stopServer();
  if (process.platform !== "darwin") app.quit();
});
